package FetchTweets;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.supercsv.io.CsvListReader;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

/**
 * 
 * @author carsonchen
 *
 */
public class Combine {
	
	private static final CsvPreference DELIMITED1 = new CsvPreference.Builder('|', ' ', "\n").build();
	
	private static final CsvPreference DELIMITED2 = new CsvPreference.Builder(' ', '|', "\n").build();
	
	private static Set<String> set;

	public static void main(String[] args) throws Exception {
		
		//File file = new File("/Users/carsonchen/PycharmProjects/test/tweetsData/");
		
		String[] companies = {"$VZ","$CMCSA","$F","$GT","$MPAA","$SMP","$GPRO","$COKE","$DPS","$MNST","$PEP","$CPB","$GIS","$K","$KRFT",
                "$TSN","$SJM","$CL","$PG","$REV","$MORN","$LOGI","$HPQ","$AMND","$AAPL","$BBRY","$GRMN","$MSI","$COF",
                "$CIT","$BAC","$WFC","$ANF","$ARO","$AEO","$BURL","$DSW","$EXPR","$FOSL","$URBN","$JCP","$KSS","$M",
                "$DG","$DLTR","$TGT","$WMT","$CVS","$WAG","$BBY","$HHG","$RSH","$SHOS","$SWY","$WFM","$LOW","$HD","$AMZN",
                "$OSTK","$ADBE","$CSCO","$YHOO","$FB","$GOOG","$MSFT"};
        
		int count = 0;
		
		for (int i =0;i<companies.length;i++){
			
			set = new HashSet<String>();
			
//			String path1 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"@Nov-29-2014.csv";
//			read(path1);
//			String path2 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"night@Nov-29-2014.csv";
//			read(path2);
//			String path3 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"@Nov-30-2014.csv";
//			read(path3);
//			String path4 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"night@Nov-30-2014.csv";
//			read(path4);
//			String path5 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"@Dec-01-2014.csv";
//			read(path5);
			String path1 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"night@Dec-01-2014.csv";
			read(path1);
			String path2 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"@Dec-02-2014.csv";
			read(path2);
//			String path3 = "/Users/carsonchen/PycharmProjects/test/tweetsData/"+companies[i]+"night@Nov-28-2014.csv";
//			read(path3);
			
			count++;
			write(companies[i]);
		}
		 System.out.println("Length is: "+companies.length);
		 System.out.println("Count is: "+count);
		
		System.out.println("Done");
		
        
		
		

	}
	
	public static void read(String path) throws Exception {
		
		List<String> row = null;
	    CsvListReader csvReader = new CsvListReader(new FileReader(path),DELIMITED1);
	    System.out.println(path);
	    
	    
	    while((row=csvReader.read())!=null){
	    	
	    	//System.out.println(row.get(0));
	    	
//	    	for(int i=0;i<row.size();i++){
//	    		System.out.println(row.get(i));
//	    	}
	    	String str = row.get(0);
	    	
	    	set.add(str);
	    	
	    	
	    }
	   
	    //System.exit(-1);
	}
	
	public static void write(String company) throws Exception{
		
		
	    FileWriter fw = new FileWriter("/Users/carsonchen/Desktop/tweetsData/Dec-02/"+company+".csv",true);
		CsvListWriter writer = new CsvListWriter(fw,DELIMITED2);
		
		for(Iterator<String> iterator = set.iterator(); iterator.hasNext();) {
			String tweet = iterator.next();
			writer.write(tweet);
		}
		writer.close();
	    System.out.println("Company "+company+" done");
	}

}

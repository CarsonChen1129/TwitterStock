package FetchTweets;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

import winterwell.jtwitter.OAuthSignpostClient;
import winterwell.jtwitter.Twitter;

/**
 * 
 * @author carsonchen
 *
 */
public class FetchTweetsJTwitter {
	
	private static String consumer_key 		= "WvncVNAYwfC9Hh1KyQ1VAv3Yv";
	private static String consumer_secret 	= "n7gDcIypn7MfbwrQKXU4igmFo02TdgsWS14jiWqoNz9lztG36S";
	private static String access_token		= "196184627-NzpAgCf6CD0Blm4EUozSmLLQBcdLLHJqNmRvpQku";
	private static String access_secret		= "uhx0blZY1AnnAOXnqfU5K2QhI4EBmVgbr4o5gdUWNNmGK";
	
private static final CsvPreference DELIMITED = new CsvPreference.Builder(' ', '|', "\n").build();
	
	public static void main(String[] args)throws IOException {
		
//		ConfigurationBuilder cb = new ConfigurationBuilder();
//		cb.setDebugEnabled(true)
//		.setOAuthConsumerKey(consumer_key)
//		.setOAuthConsumerSecret(consumer_secret)
//		.setOAuthAccessToken(access_token)
//		.setOAuthAccessTokenSecret(access_secret)
//		.setJSONStoreEnabled(true);
		
		//CsvListWriter writer = new CsvListWriter(new FileWriter("tweets_edit4.csv"),DELIMITED);
		
		OAuthSignpostClient client = new OAuthSignpostClient(consumer_key,consumer_secret,access_token,access_secret);
		Twitter twitter = new Twitter("CarsonChenJJ",client);
		
		System.out.println(twitter.getStatus());
		
//		Query query = new Query("lang:en AND #GOOG AND #Google");
//		//query.since("2014-11-12");
//		query.setSince("2014-9-11");
//		QueryResult result;
//		int count = 0;
//		
//		do {
//			result = twitter.search(query);
//			List<Status> tweets = result.getTweets();
//			for (Status tweet : tweets) {
//				System.out.println(tweet.getCreatedAt()+": @"+tweet.getUser().getScreenName()+"-"+tweet.getText());
//				writer.write(tweet.getText());
//			}
//			System.out.println("Count is: "+count);
//			count++;
//		}while ((query = result.nextQuery()) != null && count <100);
//		
//		writer.close();
//		System.out.println("Done");
		
		

	}

}
